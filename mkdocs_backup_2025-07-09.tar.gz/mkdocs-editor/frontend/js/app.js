document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Проверка поддержки API
    if (!window.Promise || !window.fetch) {
      throw new Error('Browser not supported');
    }

    // Проверка наличия необходимых компонентов перед инициализацией
    if (typeof FileExplorer === 'undefined' || typeof Editor === 'undefined' || typeof Preview === 'undefined') {
      throw new Error('Required components are not loaded');
    }

    // Инициализация модулей с проверкой их доступности
    await Promise.all([
      typeof Editor.init === 'function' ? Editor.init() : Promise.resolve(),
      typeof FileExplorer.init === 'function' ? FileExplorer.init() : Promise.resolve(),
      typeof Preview.init === 'function' ? Preview.init() : Promise.resolve(),
      typeof MaterialShortcuts === 'object' && typeof MaterialShortcuts.init === 'function' ? 
        MaterialShortcuts.init() : Promise.resolve()
    ]);

    // Обработчики для кнопок файлового менеджера
    document.getElementById('new-folder')?.addEventListener('click', async (e) => {
      console.log('New folder button clicked directly');
      await FileExplorer.createNewDirectory();
    });

    // Инициализация просмотрщика изображений
    if (window.imageViewer && typeof window.imageViewer.init === 'function') {
      await window.imageViewer.init();
    }

    // Настройка обработчиков
    document.getElementById('refresh-preview')?.addEventListener('click', () => {
      if (typeof Editor.getContent === 'function' && typeof Preview.refresh === 'function') {
        Preview.refresh(Editor.getContent());
      }
    });

    // Первоначальная загрузка
    if (typeof FileExplorer.loadFiles === 'function') {
      await FileExplorer.loadFiles();
    }
    
    if (typeof Preview.refresh === 'function') {
      Preview.refresh('# Welcome to MkDocs Editor');
    }

  } catch (error) {
    console.error('Initialization error:', error);
    
    // Fallback для превью
    const previewContainer = document.getElementById('preview-content');
    if (previewContainer) {
      previewContainer.innerHTML = `
        <div class="preview-error">
          <i class="mdi mdi-alert-circle"></i>
          <span>Initialization Error: ${error.message}</span>
        </div>
      `;
    }
  }
});

// Обработчик для кнопки превью
document.getElementById('toggle-preview')?.addEventListener('click', function() {
    const preview = document.getElementById('preview-container');
    if (!preview) return;

    preview.classList.toggle("hidden");

    // Обновляем размеры редактора при переключении
    if (typeof Editor !== 'undefined' && Editor.codemirror) {
        Editor.codemirror.refresh();
    }

    // Обновляем содержимое превью если оно становится видимым
    if (!preview.classList.contains("hidden")) {
        if (typeof Preview.refresh === 'function' && typeof Editor.getContent === 'function') {
            Preview.refresh(Editor.getContent());
        }
    }
});

// document.addEventListener('DOMContentLoaded', async () => {
//   try {
//     // Проверка поддержки API
//     if (!window.Promise || !window.fetch) {
//       throw new Error('Browser not supported');
//     }
//     // ВРЕМЕННЫЙ КОД - можно удалить после отладки
//     // Добавьте эту проверку
//     // console.log('Checking button elements...');
//     // console.log('new-file button:', document.getElementById('new-file'));
//     // console.log('new-folder button:', document.getElementById('new-folder'));
//     // console.log('refresh-files button:', document.getElementById('refresh-files'));
//     // console.log('Initializing FileExplorer...');
//     // Убедитесь, что FileExplorer инициализирован
//     if (!FileExplorer.fileTreeElement) {
//       console.error('FileExplorer not initialized properly');
//       await FileExplorer.init();
//     }
//     console.log('FileExplorer initialized');
//     // КОНЕЦ ВРЕМЕННОГО КОДА

//     // Инициализация модулей
//     await Promise.all([
//       Editor.init(),
//       FileExplorer.init(),
//       Preview.init(),
//       MaterialShortcuts.init()
//     ]);

//   document.getElementById('new-folder')?.addEventListener('click', async (e) => {
//     console.log('New folder button clicked directly');
//     await FileExplorer.createNewDirectory();
//   });

//     // Инициализация просмотрщика изображений
//     if (window.imageViewer) {
//       await window.imageViewer.init();
//     }

//     // Настройка обработчиков
//     //document.getElementById('refresh-files')?.addEventListener('click', () => FileExplorer.loadFiles());
//     //document.getElementById('new-file')?.addEventListener('click', () => FileExplorer.createNewFile());
//     document.getElementById('refresh-preview')?.addEventListener('click', () => Preview.refresh(Editor.getContent()));

//     // Первоначальная загрузка
//     await FileExplorer.loadFiles();
//     Preview.refresh('# Welcome to MkDocs Editor');

//   } catch (error) {
//     console.error('Initialization error:', error);
//     alert(`Initialization failed: ${error.message}`);

//     // ВРЕМЕННЫЙ КОД - можно удалить после отладки
//     // const errorDiv = document.createElement('div');
//     // errorDiv.style.color = 'red';
//     // errorDiv.style.padding = '20px';
//     // errorDiv.innerHTML = `<strong>Error:</strong> ${error.message}`;
//     // document.body.prepend(errorDiv);
//     // КОНЕЦ ВРЕМЕННОГО КОДА
    
//     // Fallback для превью
//     const previewFrame = document.getElementById('preview-frame');
//     if (previewFrame) {
//       previewFrame.srcdoc = `
//         <html><body style="color:red;padding:20px">
//           <strong>Initialization Error:</strong> ${error.message}
//         </body></html>
//       `;
//     }
//   }
// });

// // Обработчик для кнопки превью
// document.getElementById('toggle-preview')?.addEventListener('click', function() {
//   const preview = document.getElementById('preview-container');
//   preview.classList.toggle('hidden');
  
//   // Обновляем размеры редактора при переключении
//   if (Editor.codemirror) {
//     Editor.codemirror.refresh();
//   }
  
//   // Обновляем содержимое превью если оно становится видимым
//   if (!preview.classList.contains('hidden')) {
//     Preview.refresh(Editor.getContent());
//   }
// });
